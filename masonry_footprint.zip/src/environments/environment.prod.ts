export const environment = {
  production: true,
  firebase: {
    // apiKey: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    // authDomain: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    // databaseURL: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    // projectId: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    // storageBucket: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    // messagingSenderId: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

    apiKey: "AIzaSyCSNXc7ReCPqpgn1tTiMFIFc_BDI7XsoxM",
    authDomain: "footprints-6ccc5.firebaseapp.com",
    databaseURL: "https://footprints-6ccc5.firebaseio.com",
    projectId: "footprints-6ccc5",
    storageBucket: "footprints-6ccc5.appspot.com",
    messagingSenderId: "1013289143541",
    appId: "1:1013289143541:web:2cf98ffc280984185a49bc",
    measurementId: "G-NFMK22684T"
  }
};
