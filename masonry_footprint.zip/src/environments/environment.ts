// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCSNXc7ReCPqpgn1tTiMFIFc_BDI7XsoxM",
    authDomain: "footprints-6ccc5.firebaseapp.com",
    databaseURL: "https://footprints-6ccc5.firebaseio.com",
    projectId: "footprints-6ccc5",
    storageBucket: "footprints-6ccc5.appspot.com",
    messagingSenderId: "1013289143541",
    appId: "1:1013289143541:web:2cf98ffc280984185a49bc",
    measurementId: "G-NFMK22684T"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
