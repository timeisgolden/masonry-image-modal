export { Lightbox } from './lightbox.service';
export { LightboxConfig } from './lightbox-config.service';
export { LightboxEvent, LIGHTBOX_EVENT, IAlbum, IEvent } from './lightbox-event.service';
export { LightboxModule } from './lightbox.module';
