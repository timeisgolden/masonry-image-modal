export class Ft_image {
    id?: string;
    url: string;
    ips?: string[];
    likes?: number;
    poster: string;
    essence: string;
    footprint: string;
    timestamp?: number;
    isShow?: boolean;
    nindex?: number;
    footPrinted?: boolean;
}