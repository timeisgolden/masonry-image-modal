import { Models } from './models.model';

describe('Models', () => {
  it('should create an instance', () => {
    expect(new Models()).toBeTruthy();
  });
});
