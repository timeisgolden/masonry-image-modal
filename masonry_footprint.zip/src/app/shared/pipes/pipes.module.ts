import { NgModule } from '@angular/core';
import { CountAbtractPipe } from './count-abtract.pipe';

@NgModule({
  declarations: [
    CountAbtractPipe
  ],
  imports: [],
  exports: [
    CountAbtractPipe
  ]
})
export class PipesModule { }
