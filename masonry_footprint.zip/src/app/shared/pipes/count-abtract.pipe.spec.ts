import { CountAbtractPipe } from './count-abtract.pipe';

describe('CountAbtractPipe', () => {
  it('create an instance', () => {
    const pipe = new CountAbtractPipe();
    expect(pipe).toBeTruthy();
  });
});
